#include <iostream>
#include<string>
#include<iomanip>
#include "Course.h"

using namespace std;
#include "Course.h"


string Course::GetStudentCourse() const
{
	return studentCourse;
}
void  toString() 
{

}