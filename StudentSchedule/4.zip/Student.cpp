#include <iostream>
#include<string>
#include<iomanip>

using namespace std;


#include "Student.h"

string Student::GetStudentID() const
{
	return studentID;
}
